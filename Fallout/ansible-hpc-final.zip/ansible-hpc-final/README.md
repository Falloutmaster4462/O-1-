# Challenge 2 — Ansible Automation

Full Ansible automation for a 3-node Rocky Linux 9.7 HPC cluster.  
All roles are **idempotent**: re-running any playbook on an already-configured node produces **zero unintended changes**.

---

## Cluster Reference

| Role         | Hostname   | IP             | OS              |
|--------------|------------|----------------|-----------------|
| Head Node    | hpc-head   | 192.168.56.10  | Rocky Linux 9.7 |
| Compute Node | hpc-node01 | 192.168.56.11  | Rocky Linux 9.7 |
| Compute Node | hpc-node02 | 192.168.56.12  | Rocky Linux 9.7 |

**Admin user:** `hpcadmin` · **Control node:** Windows + WSL Ubuntu

---

## Project Layout

```
ansible-hpc/
├── ansible.cfg                          # Connection defaults, fact caching, pipelining
├── site.yml                             # Master playbook (all roles, all nodes)
├── requirements.yml                     # Galaxy collection dependencies
├── run1.txt                             # Captured output — Run 1 (initial apply)
├── run2.txt                             # Captured output — Run 2 (idempotence proof)
├── inventory/
│   └── hosts.ini                        # Static inventory — head + compute groups
├── group_vars/
│   └── cluster.yml                      # All shared variables: packages, users, SSH, firewall
├── playbooks/
│   ├── bootstrap.yml                    # First-time-only: create hpcadmin, push key
│   ├── distribute-intracluster-keys.yml # Generate & distribute intra-cluster ed25519 key
│   └── verify.yml                       # Read-only post-run verification (no changes)
└── roles/
    ├── common/          # SELinux enforcing, chrony/NTP, hostname, timezone
    ├── hosts-file/      # Idempotent /etc/hosts population (blockinfile + marker)
    ├── users/           # hpcadmin creation, wheel sudo, SSH authorized_keys
    ├── base-packages/   # EPEL, CRB, core tools, btop, nftables, scientific stack
    ├── firewall/        # firewalld: SSH service + intra-cluster trusted rich rule
    └── ssh-hardening/   # Drop-in sshd_config.d — no-password, modern ciphers
```

---

## Bootstrap Prerequisites

### 1 · Control node setup (WSL Ubuntu on Windows)

Install Ansible and required collections:

```bash
sudo apt update && sudo apt install -y python3 python3-pip sshpass
pip3 install ansible --break-system-packages
export PATH=$PATH:~/.local/bin
ansible-galaxy collection install ansible.posix community.general
```

| Requirement | Minimum | Notes |
|---|---|---|
| ansible-core | 2.14+ | Installed via pip |
| ansible.posix | latest | `firewalld`, `selinux`, `authorized_key` modules |
| community.general | latest | `timezone` module |
| Python 3 | 3.9+ | |
| OpenSSH client | 8+ | Ships with WSL Ubuntu |

### 2 · Generate SSH key pair

```bash
ssh-keygen -t ed25519 -C "hpc-cluster-admin" -f ~/.ssh/hpc_cluster_key
# Press Enter twice for no passphrase
```

### 3 · Prepare VMs for bootstrap (run once per VM in VirtualBox console)

Each VM starts with only root + password access. Run these commands on each VM console as the local user (e.g. `jazz`):

```bash
sudo passwd root                               # set a root password
sudo sed -i '/^PermitRootLogin/d' /etc/ssh/sshd_config
echo "PermitRootLogin yes" | sudo tee -a /etc/ssh/sshd_config
sudo systemctl restart sshd
```

### 4 · Verify network reachability

```bash
ping 192.168.56.10 -c 2
ping 192.168.56.11 -c 2
ping 192.168.56.12 -c 2
```

---

## Execution Order

Run playbooks in this exact order on first provisioning:

### Step 1 — Bootstrap (first time only)

Temporarily connect as root to create `hpcadmin` and push the SSH key:

```bash
cd ~/ansible-hpc

# Switch to root user for bootstrap:
sed -i 's/^remote_user.*/remote_user        = root/' ansible.cfg

# Run bootstrap — enter root password when prompted:
ansible-playbook playbooks/bootstrap.yml \
  --ask-pass \
  -e "admin_public_key_file=~/.ssh/hpc_cluster_key.pub"

# Restore hpcadmin as default user:
sed -i 's/^remote_user.*/remote_user        = hpcadmin/' ansible.cfg

# Verify connectivity:
ansible cluster -m ping
```

> **Alternative:** If you prefer not to swap `ansible.cfg`, use the manual shell commands documented inside `bootstrap.yml`.

> **Skip** if `hpcadmin` already exists with key-based SSH access.

### Step 2 — Full cluster configuration

```bash
ansible-playbook site.yml | tee run1.txt
```

Expected: all tasks `ok` or `changed`, zero `failed`.

### Step 3 — Verify configuration

```bash
ansible-playbook playbooks/verify.yml
```

Checks: services running, packages installed, hostnames resolving, SSH hardened, SELinux enforcing, NTP synced, firewall active.

### Step 4 — Prove idempotence (second run)

```bash
ansible-playbook site.yml | tee run2.txt
grep "PLAY RECAP" -A4 run2.txt
```

Every node must show `changed=0`.

### Step 5 — Distribute intra-cluster SSH keys (optional)

Required for MPI jobs and intra-cluster SSH from hpc-head:

```bash
ansible-playbook playbooks/distribute-intracluster-keys.yml
```

---

## Running Individual Roles (Tags)

```bash
# Only install packages
ansible-playbook site.yml --tags packages

# Only harden SSH
ansible-playbook site.yml --tags ssh

# Only update /etc/hosts
ansible-playbook site.yml --tags hosts

# Dry-run — shows what would change without doing it
ansible-playbook site.yml --check --diff
```

Available tags: `common`, `hosts`, `users`, `packages`, `firewall`, `ssh`, `verify`

---

## Idempotence Proof

The table below records actual Ansible task outcomes from two consecutive runs on the same 3-node cluster. `run1.txt` and `run2.txt` (included in this repository) capture the full output.

**PLAY RECAP — Run 1 (initial configuration):**
```
hpc-head   : ok=37  changed=16  unreachable=0  failed=0  skipped=2
hpc-node01 : ok=37  changed=16  unreachable=0  failed=0  skipped=2
hpc-node02 : ok=37  changed=16  unreachable=0  failed=0  skipped=2
```

**PLAY RECAP — Run 2 (idempotence proof):**
```
hpc-head   : ok=35  changed=0  unreachable=0  failed=0  skipped=2
hpc-node01 : ok=35  changed=0  unreachable=0  failed=0  skipped=2
hpc-node02 : ok=35  changed=0  unreachable=0  failed=0  skipped=2
```

**Run 2 result: `changed=0` on all three nodes. ✅**

### Per-task breakdown

| Role | Task | Run 1 | Run 2 |
|---|---|:---:|:---:|
| **common** | Ensure SELinux is enforcing | `changed` | `ok` |
| **common** | Install chrony | `ok` | `ok` |
| **common** | Deploy chrony configuration | `changed` | `ok` |
| **common** | Ensure chronyd enabled and running | `ok` | `ok` |
| **common** | Set hostname via systemd | `ok` | `ok` |
| **common** | Set timezone to UTC | `changed` | `ok` |
| **hosts-file** | Populate /etc/hosts with cluster nodes | `changed` | `ok` |
| **hosts-file** | Verify all cluster hostnames resolve | `ok` | `ok` |
| **users** | Ensure cluster admin group exists | `ok` | `ok` |
| **users** | Create hpcadmin user | `changed` | `ok` |
| **users** | Set up .ssh directory | `ok` | `ok` |
| **users** | Deploy authorised public keys | `ok` | `ok` |
| **users** | Configure passwordless sudo | `ok` | `ok` |
| **users** | Lock root account password | `changed` | `ok` |
| **base-packages** | Install EPEL repository | `changed` | `ok` |
| **base-packages** | Enable CRB repository | `ok`* | `ok`* |
| **base-packages** | Install core base packages | `changed` | `ok` |
| **base-packages** | Install scientific computing packages | `changed` | `ok` |
| **base-packages** | Install btop (EPEL) | `ok` | `ok` |
| **base-packages** | Install nftables | `ok` | `ok` |
| **base-packages** | Add OpenMPI to profile.d | `changed` | `ok` |
| **base-packages** | Upgrade pip | `changed` | `ok` |
| **base-packages** | Install Python scientific packages | `changed` | `ok` |
| **firewall** | Install firewalld | `ok` | `ok` |
| **firewall** | Enable and start firewalld | `ok` | `ok` |
| **firewall** | Allow SSH service (permanent) | `ok` | `ok` |
| **firewall** | Allow intra-cluster rich rule | `changed` | `ok` |
| **firewall** | Reload firewalld | `ok`† | `ok`† |
| **ssh-hardening** | Ensure sshd_config.d exists | `changed` | `ok` |
| **ssh-hardening** | Deploy SSH hardening drop-in | `changed` | `ok` |
| **ssh-hardening** | Ensure sshd enabled and running | `ok` | `ok` |
| **ssh-hardening** | Verify SSH config syntax | `ok` | `ok` |
| **site.yml post** | Verify sshd active | `ok` | `ok` |
| **site.yml post** | Verify firewalld active | `ok` | `ok` |
| **site.yml post** | Verify chronyd active | `ok` | `ok` |

> \* `changed_when: false` — `dnf config-manager` always exits 0; idempotence managed by the dnf package tasks.  
> † `changed_when: false` — `firewall-cmd --reload` is a safe no-op when rules are already applied.

---

## Key Idempotence Techniques

| Technique | Where applied |
|---|---|
| `ansible.builtin.blockinfile` with unique `marker` | `/etc/hosts` — block never duplicated |
| `ansible.posix.authorized_key` with `state: present` | SSH keys — appends, never overwrites |
| `ansible.builtin.copy` with `validate:` | sudoers drop-in — visudo validates before writing |
| `ansible.builtin.template` with `backup: true` | `sshd_config.d`, `chrony.conf` — only writes on content diff |
| `ansible.posix.firewalld` with `permanent: true, immediate: true` | firewall rules — module checks state before applying |
| `ansible.builtin.dnf` with `state: present` | all packages — skips if already installed |
| `ansible.builtin.systemd` with `state: started, enabled: true` | all services — no-op if already running |
| `changed_when: false` on command/shell tasks | `dnf config-manager`, `firewall-cmd --reload`, verify tasks |

---

## Variables Reference

All variables live in `group_vars/cluster.yml` and can be overridden per-host in `host_vars/<hostname>.yml`.

| Variable | Default | Description |
|---|---|---|
| `cluster_admin_user` | `hpcadmin` | Primary cluster admin username |
| `cluster_admin_groups` | `[wheel]` | Groups for admin user |
| `cluster_users` | `[]` | Additional users to create (see cluster.yml for format) |
| `base_packages_core` | see cluster.yml | Core packages installed on all nodes |
| `base_packages_scientific` | see cluster.yml | Scientific/HPC packages |
| `ssh_permit_root_login` | `"no"` | SSH PermitRootLogin value |
| `ssh_password_authentication` | `"no"` | SSH PasswordAuthentication value |
| `ssh_max_auth_tries` | `3` | MaxAuthTries for sshd |
| `firewall_trusted_networks` | `["192.168.56.0/24"]` | Networks accepted without service filter |
| `cluster_hosts` | head + 2 computes | List of hosts for /etc/hosts population |
| `chrony_servers` | rocky NTP pool | NTP pool configuration |

---

## Known Platform Notes

| Issue | Explanation | Fix applied |
|---|---|---|
| `vim` package not found by `package_facts` | Rocky/RHEL packages vim as `vim-enhanced`; `package_facts` reports the real RPM name, not the virtual provide | `base_packages_core` and `verify.yml` both use `vim-enhanced` |
| `community.general.yaml` callback removed | community.general v12+ removed the yaml callback plugin | `ansible.cfg` uses built-in `stdout_callback = default` |
| `ansible_selinux` deprecation warning | Top-level `ansible_*` fact injection deprecated in ansible-core 2.17+ | `verify.yml` uses `ansible_facts['selinux']` dict syntax |
| `libselinux-python` missing on fresh nodes | The `ansible.posix.selinux` module requires python3-libselinux on the managed node | `bootstrap.yml` installs `python3-libselinux` via `raw` before any other task |

---

## Troubleshooting

**`UNREACHABLE` on all nodes**  
→ `ping 192.168.56.10` fails. The host-only adapter is not up. On each VM run: `nmcli con up eth1`

**`Permission denied (publickey)` when running site.yml**  
→ Bootstrap has not been run yet, or `ansible.cfg` still has `remote_user = root`. Run bootstrap first, then restore `remote_user = hpcadmin`.

**`Module not found: ansible.posix` or `community.general`**  
→ Run: `ansible-galaxy collection install ansible.posix community.general`

**`Task Deploy SSH hardening drop-in fails sshd -t validation`**  
→ A syntax error in the template. Check that all SSH variables in `group_vars/cluster.yml` are quoted strings (`"no"` not bare `no`).

**Second run still shows `changed` on firewall tasks**  
→ `firewall-cmd --reload` always reports `ok` (`changed_when: false`). If `ansible.posix.firewalld` tasks show `changed`, the rule was missing — verify the first run completed without errors.
