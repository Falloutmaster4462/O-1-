# Decision Log — Challenge 1: Zero-to-Cluster Bootstrap

## How We Did It

We provisioned three VirtualBox VMs from a Rocky Linux 9.4 minimal ISO, each with 1 vCPU and 2 GB RAM. Every VM was given two network adapters: NAT (for internet access during setup) and a host-only adapter on the `192.168.56.0/24` subnet to simulate an HPC private network without a physical switch.

We configured static IPs on the host-only interface using `nmcli`, set hostnames with `hostnamectl`, and populated `/etc/hosts` on all nodes so name resolution works without DNS. We created a dedicated `hpcadmin` user with sudo rights, generated ed25519 SSH keys, and distributed them so the local workstation can reach all nodes and the head node can reach compute nodes directly. We then applied SSH hardening via a drop-in config file and locked down firewall rules with `firewalld`.

## Why We Chose This Approach

### Rocky Linux 9.4

| Option | Reason for/against |
|--------|-------------------|
| **Rocky Linux 9.4** ✅ | RHEL-compatible, widely used in HPC, excellent `dnf` ecosystem, SELinux enforcing by default |
| CentOS Stream 9 | Rolling target — less stable for reproducible HPC builds |
| Ubuntu Server 24.04 | Good option but RHEL-family is industry standard in HPC (Slurm, OpenMPI docs assume it) |
| AlmaLinux 9 | Functionally equivalent to Rocky — either would work; Rocky chosen for familiarity |

### Network: Host-Only Adapter (no physical switch)

| Option | Reason for/against |
|--------|-------------------|
| **Host-only adapter** ✅ | Simulates private HPC network, no extra hardware needed, reproducible on any laptop |
| Bridged adapter | Depends on physical network; IP assignment unpredictable; not reproducible |
| Internal network (VirtualBox) | Nodes can't reach internet for package installs |
| NAT only | Nodes can't directly address each other by private IP |

We kept NAT as Adapter 1 for package downloads and used host-only as Adapter 2 for cluster communication. This mimics a real dual-NIC HPC node (management + compute network).

### SSH Strategy: ProxyJump

| Option | Reason for/against |
|--------|-------------------|
| **ProxyJump via head node** ✅ | Clean, modern, no SSH agent forwarding needed, single key file on laptop |
| SSH agent forwarding (`-A`) | Security risk — agent socket exposed on intermediate host |
| VPN to each node | Overkill for a 3-node lab; adds complexity |
| Direct access to compute nodes | Would require all nodes to have public/reachable IPs — not realistic in HPC |

ProxyJump means the compute nodes never need to be directly reachable from outside the cluster. This matches real-world HPC topology where only the head/login node is exposed.

### Key Type: ed25519

| Option | Reason for/against |
|--------|-------------------|
| **ed25519** ✅ | Smallest key, fastest, most modern, recommended by NIST and SSH hardening guides |
| RSA 4096 | Still secure but larger and slower; ed25519 is preferred for new deployments |
| RSA 2048 | Below current recommendations for long-lived keys |
| ECDSA | Good, but ed25519 has simpler implementation and wider audit history |

### Static IPs via nmcli (no DHCP)

| Option | Reason for/against |
|--------|-------------------|
| **Static IPs via nmcli** ✅ | Reproducible, predictable, no dependency on DHCP server |
| DHCP reservations | Requires DHCP server config — adds a moving part in a lab environment |
| `/etc/network/interfaces` | Not native to RHEL; NetworkManager is the standard |

### User Management: Single `hpcadmin` User

| Option | Reason for/against |
|--------|-------------------|
| **Single shared `hpcadmin`** ✅ | Simple for a 3-node lab; matches minimal scope of challenge |
| Individual user accounts per team member | Better for production; overkill here and harder to automate key distribution |
| Root login enabled | Hard security anti-pattern; rejected immediately |

---

## Trade-offs Accepted

- **No DNS server** — `/etc/hosts` works for 3 nodes but doesn't scale. In a real cluster we'd deploy `bind` or use `dnsmasq`.
- **Passwordless sudo** — convenient for a lab but would be restricted to specific commands in production.
- **No Ansible/automation** — all steps done manually to demonstrate understanding; automation would be the next step.
- **VirtualBox host-only** — not identical to a real NIC but close enough for the topology goals of this challenge.
